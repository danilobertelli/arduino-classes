﻿# Course Work 2.1 - INF-742 Design and operation principles of cyber-physical systems in the IoT
# Nome do aluno: Danilo Arthur Bertelli
# Nome do aluno: Danilo Arthur Bertelli

# 1 Instruções para compilação, colocar os sensores nos pinos:
BUZZER_PIN = D4;
MOTION_PIN = D7;
ENCODER = D2/D3;

# 2 Abrir coursework-2.1.ino na IDE, compilar e executar.

