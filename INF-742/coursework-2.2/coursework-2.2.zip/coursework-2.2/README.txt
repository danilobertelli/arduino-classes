﻿# Course Work 2.2 - INF-742 Design and operation principles of cyber-physical systems in the IoT
# Nome do aluno: Danilo Arthur Bertelli
# Nome do aluno: Marcel Cunha

# 1 Instruções para compilação, colocar os sensores nos pinos:
SERVO = D6;
ENCODER = D2/D3;

# 2 Abrir coursework-2.2.ino na IDE, compilar e executar.

