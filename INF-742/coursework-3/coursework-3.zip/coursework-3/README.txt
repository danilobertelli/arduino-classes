﻿# Course Work 3 - INF-742 Design and operation principles of cyber-physical systems in the IoT
# Nome do aluno: Danilo Arthur Bertelli

# 1 Instruções para compilação, colocar os sensores nos pinos:
BUZZER= 3;
BOTAO = 2;
"SENSOR" = A0 / 3.3v

# 2 Abrir coursework-3.ino na IDE, compilar e executar.

